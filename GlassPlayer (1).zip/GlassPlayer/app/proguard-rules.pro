# Default rules are enough; media3 and coil ship consumer rules.
