package com.glassplayer.app.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.glassplayer.app.R
import com.glassplayer.app.data.AppSettings
import com.glassplayer.app.ui.glass.GlassSurface
import com.glassplayer.app.ui.theme.LocalGlass

@Composable
fun SettingsScreen(settings: AppSettings, onChange: (AppSettings) -> Unit, accent: Color) {
    val g = LocalGlass.current
    val ctx = LocalContext.current
    val version = remember(ctx) {
        runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull().orEmpty()
    }
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(
            start = 16.dp, end = 16.dp, bottom = 120.dp + bottomInset,
        ),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        item {
            Text(
                stringResource(R.string.settings_title),
                color = g.text,
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.statusBarsPadding().padding(top = 8.dp, bottom = 6.dp),
            )
        }
        item { SectionLabel(stringResource(R.string.section_playback)) }
        item {
            SettingsCard {
                SettingRow(
                    stringResource(R.string.set_background), stringResource(R.string.set_background_desc),
                    settings.backgroundPlayback, accent,
                ) { onChange(settings.copy(backgroundPlayback = it)) }
                SettingRow(
                    stringResource(R.string.set_pip), stringResource(R.string.set_pip_desc),
                    settings.autoPip, accent,
                ) { onChange(settings.copy(autoPip = it)) }
                SettingRow(
                    stringResource(R.string.set_rotate), stringResource(R.string.set_rotate_desc),
                    settings.matchOrientation, accent,
                ) { onChange(settings.copy(matchOrientation = it)) }
                SettingRow(
                    stringResource(R.string.set_resume), stringResource(R.string.set_resume_desc),
                    settings.resume, accent,
                ) { onChange(settings.copy(resume = it)) }
            }
        }
        item { SectionLabel(stringResource(R.string.section_appearance)) }
        item {
            SettingsCard {
                SettingRow(
                    stringResource(R.string.set_dynamic), stringResource(R.string.set_dynamic_desc),
                    settings.dynamicColors, accent,
                ) { onChange(settings.copy(dynamicColors = it)) }
            }
        }
        item { SectionLabel(stringResource(R.string.about)) }
        item {
            SettingsCard {
                Column(Modifier.padding(16.dp)) {
                    Text(stringResource(R.string.app_name), color = g.text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    Text(stringResource(R.string.version, version), color = g.textSecondary, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text,
        color = LocalGlass.current.textSecondary,
        fontSize = 14.sp,
        fontWeight = FontWeight.Medium,
        modifier = Modifier.padding(start = 8.dp, top = 8.dp),
    )
}

@Composable
private fun SettingsCard(content: @Composable () -> Unit) {
    GlassSurface(Modifier.fillMaxWidth(), RoundedCornerShape(24.dp), contentAlignment = Alignment.TopStart) {
        Column(Modifier.fillMaxWidth()) { content() }
    }
}

@Composable
private fun SettingRow(
    title: String,
    description: String,
    checked: Boolean,
    accent: Color,
    onChecked: (Boolean) -> Unit,
) {
    val g = LocalGlass.current
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = g.text, fontSize = 16.sp, fontWeight = FontWeight.Medium)
            Text(description, color = g.textSecondary, fontSize = 13.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChecked,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = accent,
                uncheckedThumbColor = Color.White,
                uncheckedTrackColor = g.textSecondary.copy(alpha = 0.45f),
                uncheckedBorderColor = Color.Transparent,
            ),
        )
    }
}
