package com.glassplayer.app.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.glassplayer.app.data.AppSettings
import com.glassplayer.app.data.LayoutMode
import com.glassplayer.app.data.Prefs
import com.glassplayer.app.data.SortOrder
import com.glassplayer.app.data.VideoItem
import com.glassplayer.app.data.VideoRepository
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = Prefs.get(app)
    private val repo = VideoRepository(app)

    var videos by mutableStateOf<List<VideoItem>>(emptyList())
        private set
    var loaded by mutableStateOf(false)
        private set
    var layoutMode by mutableStateOf(prefs.layoutMode)
        private set
    var sort by mutableStateOf(prefs.sort)
        private set
    var favorites by mutableStateOf(prefs.favorites())
        private set
    var settings by mutableStateOf(prefs.settings)
        private set

    var tab by mutableIntStateOf(0)
    var openFolderId by mutableStateOf<Long?>(null)

    fun refresh() {
        viewModelScope.launch {
            videos = repo.load()
            loaded = true
        }
    }

    fun toggleLayout() {
        layoutMode = if (layoutMode == LayoutMode.GRID) LayoutMode.LIST else LayoutMode.GRID
        prefs.layoutMode = layoutMode
    }

    fun setSort(order: SortOrder) {
        sort = order
        prefs.sort = order
    }

    fun toggleFavorite(id: Long) {
        favorites = if (id in favorites) favorites - id else favorites + id
        prefs.saveFavorites(favorites)
    }

    fun updateSettings(value: AppSettings) {
        settings = value
        prefs.settings = value
    }
}
