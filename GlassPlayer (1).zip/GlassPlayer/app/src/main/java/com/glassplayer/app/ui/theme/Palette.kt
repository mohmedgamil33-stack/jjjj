package com.glassplayer.app.ui.theme

import android.content.Context
import android.net.Uri
import android.util.LruCache
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.core.graphics.ColorUtils
import androidx.core.graphics.drawable.toBitmap
import androidx.palette.graphics.Palette
import coil.imageLoader
import coil.request.SuccessResult
import com.glassplayer.app.ui.thumbRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private object ColorCache {
    private val cache = LruCache<String, Int>(256)
    fun get(uri: Uri): Int? = cache.get(uri.toString())
    fun put(uri: Uri, rgb: Int) { cache.put(uri.toString(), rgb) }
}

private suspend fun computeDominant(ctx: Context, uri: Uri): Int? {
    val result = ctx.imageLoader.execute(thumbRequest(ctx, uri, sizePx = 96))
    val bitmap = (result as? SuccessResult)?.drawable?.toBitmap() ?: return null
    val palette = Palette.from(bitmap).maximumColorCount(16).generate()
    val swatch = palette.vibrantSwatch ?: palette.mutedSwatch ?: palette.dominantSwatch ?: return null
    return swatch.rgb
}

/** Dominant color of a video thumbnail, or null while it is still being computed. */
@Composable
fun rememberDominantColor(uri: Uri?): Color? {
    val ctx = LocalContext.current
    var color by remember(uri) { mutableStateOf(uri?.let { u -> ColorCache.get(u)?.let { Color(it) } }) }
    LaunchedEffect(uri) {
        if (uri != null && color == null) {
            val rgb = withContext(Dispatchers.IO) { computeDominant(ctx, uri) }
            if (rgb != null) {
                ColorCache.put(uri, rgb)
                color = Color(rgb)
            }
        }
    }
    return color
}

/** Adjusts a raw palette color so it stays readable on glass in light or dark mode. */
fun Color.asAccent(dark: Boolean): Color {
    val hsl = FloatArray(3)
    ColorUtils.colorToHSL(toArgb(), hsl)
    hsl[1] = hsl[1].coerceAtLeast(0.55f)
    hsl[2] = if (dark) 0.68f else 0.42f
    return Color(ColorUtils.HSLToColor(hsl))
}
