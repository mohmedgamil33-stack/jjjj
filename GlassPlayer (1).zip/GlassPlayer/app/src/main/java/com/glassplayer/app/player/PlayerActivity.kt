package com.glassplayer.app.player

import android.app.PictureInPictureParams
import android.content.ComponentName
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.util.Rational
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.MimeTypes
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.glassplayer.app.data.Prefs
import com.glassplayer.app.ui.theme.GlassTheme
import com.google.common.util.concurrent.ListenableFuture
import java.util.Locale
import kotlin.math.roundToInt

@OptIn(UnstableApi::class)
class PlayerActivity : ComponentActivity(), PlayerHost {

    private lateinit var prefs: Prefs
    private lateinit var audioManager: AudioManager
    private var future: ListenableFuture<MediaController>? = null
    private var controller by mutableStateOf<MediaController?>(null)
    private var inPip by mutableStateOf(false)

    private val subtitlePicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let(::attachSubtitle) }

    private val playerListener = object : Player.Listener {
        override fun onVideoSizeChanged(videoSize: VideoSize) {
            applyOrientation(videoSize)
            updatePipParams()
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            updatePipParams()
            if (!isPlaying) saveProgress()
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            updatePipParams()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs.get(this)
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        volumeControlStream = AudioManager.STREAM_MUSIC

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.also {
                it.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        hideSystemBars()

        val pending = resolveQueue(intent)

        setContent {
            GlassTheme(forceDark = true) {
                Box(Modifier.fillMaxSize().background(Color.Black)) {
                    controller?.let { PlayerScreen(it, this@PlayerActivity, inPip) }
                }
            }
        }

        connect(pending)
    }

    // ---- Session / queue -------------------------------------------------------------------

    private fun resolveQueue(i: Intent): PlayerQueue.Pending? {
        val data = i.data
        if (i.action == Intent.ACTION_VIEW && data != null) {
            val item = MediaItem.Builder()
                .setMediaId("ext:${data}")
                .setUri(data)
                .setMediaMetadata(MediaMetadata.Builder().setTitle(queryName(data)?.substringBeforeLast('.')).build())
                .build()
            return PlayerQueue.Pending(listOf(item), 0)
        }
        return PlayerQueue.take()
    }

    private fun connect(pending: PlayerQueue.Pending?) {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val f = MediaController.Builder(this, token).buildAsync()
        future = f
        f.addListener({
            val c = runCatching { f.get() }.getOrNull() ?: return@addListener
            controller = c
            c.addListener(playerListener)
            if (pending != null && pending.items.isNotEmpty()) {
                val start = pending.items[pending.index]
                val startPosition = if (prefs.settings.resume) {
                    prefs.position(start.mediaId.toLongOrNull())
                } else {
                    0L
                }
                c.setMediaItems(pending.items, pending.index, startPosition)
                c.prepare()
                c.play()
            }
            applyOrientation(c.videoSize)
            updatePipParams()
        }, ContextCompat.getMainExecutor(this))
    }

    private fun saveProgress() {
        val c = controller ?: return
        val id = c.currentMediaItem?.mediaId?.toLongOrNull() ?: return
        val duration = c.duration
        val position = c.currentPosition
        prefs.savePosition(id, if (duration > 0 && position > duration - 5_000) 0L else position)
    }

    // ---- Lifecycle -------------------------------------------------------------------------

    override fun onStop() {
        super.onStop()
        saveProgress()
        val c = controller ?: return
        // Closing the PiP window stops the video; otherwise follow the background-playback setting.
        if (isInPictureInPictureMode || !prefs.settings.backgroundPlayback) c.pause()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onDestroy() {
        saveProgress()
        controller?.removeListener(playerListener)
        future?.let { MediaController.releaseFuture(it) }
        controller = null
        super.onDestroy()
    }

    // ---- Picture in picture ----------------------------------------------------------------

    private fun pipParams(): PictureInPictureParams {
        val size = controller?.videoSize
        val ratio = if (size != null && size.width > 0 && size.height > 0) {
            (size.width.toFloat() / size.height).coerceIn(0.42f, 2.39f)
        } else {
            16f / 9f
        }
        val builder = PictureInPictureParams.Builder()
            .setAspectRatio(Rational((ratio * 1000).roundToInt(), 1000))
        if (Build.VERSION.SDK_INT >= 31) {
            builder.setAutoEnterEnabled(prefs.settings.autoPip && controller?.isPlaying == true)
        }
        return builder.build()
    }

    private fun updatePipParams() {
        if (Build.VERSION.SDK_INT >= 26 && packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) {
            runCatching { setPictureInPictureParams(pipParams()) }
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // Android 12+ enters PiP automatically; older versions need this nudge.
        if (Build.VERSION.SDK_INT < 31 && prefs.settings.autoPip && controller?.isPlaying == true) enterPip()
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        inPip = isInPictureInPictureMode
    }

    override fun enterPip() {
        if (Build.VERSION.SDK_INT >= 26 && packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE)) {
            runCatching { enterPictureInPictureMode(pipParams()) }
        }
    }

    // ---- Window / audio --------------------------------------------------------------------

    private fun hideSystemBars() {
        WindowCompat.getInsetsController(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }
    }

    private fun applyOrientation(size: VideoSize) {
        if (!prefs.settings.matchOrientation || isInPictureInPictureMode || size.width == 0) return
        requestedOrientation = if (size.width >= size.height) {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        } else {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        }
    }

    override fun toggleOrientation() {
        requestedOrientation =
            if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
                ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            } else {
                ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            }
    }

    override fun brightness(): Float {
        val current = window.attributes.screenBrightness
        if (current >= 0f) return current
        return runCatching {
            Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
        }.getOrDefault(0.5f)
    }

    override fun setBrightness(value: Float) {
        window.attributes = window.attributes.also { it.screenBrightness = value.coerceIn(0.02f, 1f) }
    }

    override fun volume(): Float {
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        return audioManager.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
    }

    override fun setVolume(value: Float) {
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        runCatching {
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, (value * max).roundToInt().coerceIn(0, max), 0)
        }
    }

    // ---- Actions ---------------------------------------------------------------------------

    override fun close(keepPlaying: Boolean) {
        if (!keepPlaying) controller?.pause()
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        finish()
    }

    override fun pickSubtitle() {
        subtitlePicker.launch(arrayOf("*/*"))
    }

    private fun attachSubtitle(uri: Uri) {
        val c = controller ?: return
        val item = c.currentMediaItem ?: return
        val name = queryName(uri).orEmpty()
        val mime = when {
            name.endsWith(".vtt", ignoreCase = true) -> MimeTypes.TEXT_VTT
            name.endsWith(".ass", ignoreCase = true) || name.endsWith(".ssa", ignoreCase = true) -> MimeTypes.TEXT_SSA
            else -> MimeTypes.APPLICATION_SUBRIP
        }
        val subtitle = MediaItem.SubtitleConfiguration.Builder(uri)
            .setMimeType(mime)
            .setLanguage(Locale.getDefault().language)
            .setLabel(name.substringBeforeLast('.').ifBlank { null })
            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
            .build()
        val updated = item.buildUpon().setSubtitleConfigurations(listOf(subtitle)).build()
        val index = c.currentMediaItemIndex
        val position = c.currentPosition
        val playing = c.playWhenReady
        c.replaceMediaItem(index, updated)
        c.seekTo(index, position)
        c.playWhenReady = playing
        c.trackSelectionParameters = c.trackSelectionParameters.buildUpon()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            .build()
    }

    private fun queryName(uri: Uri): String? =
        runCatching {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) it.getString(0) else null
            }
        }.getOrNull() ?: uri.lastPathSegment
}
