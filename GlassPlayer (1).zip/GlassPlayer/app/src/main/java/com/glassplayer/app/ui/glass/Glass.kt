package com.glassplayer.app.ui.glass

import android.os.Build
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.graphics.rememberGraphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import com.glassplayer.app.ui.theme.LocalGlass

/**
 * Records the content behind glass surfaces into one GraphicsLayer.
 * Every GlassSurface that receives this state draws a blurred copy of that layer
 * behind itself (real backdrop blur on Android 12+, translucent tint below that).
 */
@Stable
class GlassState(val layer: GraphicsLayer) {
    var origin by mutableStateOf(Offset.Zero)
}

@Composable
fun rememberGlassState(): GlassState {
    val layer = rememberGraphicsLayer()
    return remember(layer) { GlassState(layer) }
}

fun Modifier.glassSource(state: GlassState): Modifier = this
    .onGloballyPositioned { state.origin = it.positionInRoot() }
    .drawWithContent {
        state.layer.record(size = IntSize(size.width.toInt(), size.height.toInt())) {
            this@drawWithContent.drawContent()
        }
        drawLayer(state.layer)
    }

@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(24.dp),
    glass: GlassState? = null,
    tint: Color? = null,
    blur: Dp = 24.dp,
    onClick: (() -> Unit)? = null,
    contentAlignment: Alignment = Alignment.Center,
    content: @Composable BoxScope.() -> Unit = {},
) {
    val g = LocalGlass.current
    val blurPx = with(LocalDensity.current) { blur.toPx() }
    val source = glass
    val canBlur = source != null && Build.VERSION.SDK_INT >= 31
    val base = tint ?: g.tint
    val fill = if (source != null && !canBlur) base.copy(alpha = maxOf(base.alpha, 0.85f)) else base
    var pos by remember { mutableStateOf(Offset.Zero) }

    Box(
        modifier
            .clip(shape)
            .onGloballyPositioned { pos = it.positionInRoot() }
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .border(
                0.8.dp,
                Brush.linearGradient(
                    listOf(g.highlight, g.highlight.copy(alpha = 0.06f), g.highlight.copy(alpha = 0.30f)),
                ),
                shape,
            ),
        contentAlignment = contentAlignment,
    ) {
        if (canBlur && source != null) {
            Box(
                Modifier
                    .matchParentSize()
                    .graphicsLayer {
                        clip = true
                        renderEffect = BlurEffect(blurPx, blurPx, TileMode.Clamp)
                    }
                    .drawBehind {
                        translate(source.origin.x - pos.x, source.origin.y - pos.y) {
                            drawLayer(source.layer)
                        }
                    },
            )
        }
        Box(Modifier.matchParentSize().background(fill))
        Box(Modifier.matchParentSize().background(Brush.verticalGradient(listOf(g.sheen, Color.Transparent))))
        content()
    }
}

@Composable
fun GlassIconButton(
    icon: ImageVector,
    description: String?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 44.dp,
    glass: GlassState? = null,
    tint: Color? = null,
    iconColor: Color = LocalGlass.current.text,
) {
    GlassSurface(
        modifier = modifier.size(size),
        shape = CircleShape,
        glass = glass,
        tint = tint,
        onClick = onClick,
    ) {
        Icon(icon, description, tint = iconColor, modifier = Modifier.size(size * 0.5f))
    }
}

/** Soft color glow behind the whole interface; tinted by the video you are looking at. */
@Composable
fun AmbientBackground(color: Color?, modifier: Modifier = Modifier) {
    val g = LocalGlass.current
    val animated by animateColorAsState(color ?: g.accent, tween(1000), label = "ambient")
    val strength = (if (g.isDark) 0.34f else 0.26f) * (if (color == null) 0.45f else 1f)
    Box(
        modifier
            .fillMaxSize()
            .background(g.bg)
            .drawBehind {
                drawRect(
                    Brush.radialGradient(
                        listOf(animated.copy(alpha = strength), Color.Transparent),
                        center = Offset(size.width * 0.15f, size.height * 0.04f),
                        radius = size.maxDimension * 0.75f,
                    ),
                )
                drawRect(
                    Brush.radialGradient(
                        listOf(animated.copy(alpha = strength * 0.7f), Color.Transparent),
                        center = Offset(size.width * 0.95f, size.height * 0.95f),
                        radius = size.maxDimension * 0.6f,
                    ),
                )
            },
    )
}
