package com.glassplayer.app.player

import android.content.pm.PackageManager
import android.view.LayoutInflater
import androidx.activity.compose.BackHandler
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.BrightnessMedium
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.ClosedCaption
import androidx.compose.material.icons.rounded.Forward10
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PictureInPictureAlt
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Replay10
import androidx.compose.material.icons.rounded.ScreenRotation
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.ZoomIn
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.ui.PlayerView
import com.glassplayer.app.R
import com.glassplayer.app.ui.Thumb
import com.glassplayer.app.ui.glass.GlassIconButton
import com.glassplayer.app.ui.glass.GlassSurface
import com.glassplayer.app.util.formatDuration
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

private enum class Panel { NONE, SPEED, TRACKS }

private class Indicator(val icon: ImageVector, val label: String, val progress: Float?)

private class Flash(val right: Boolean, val seconds: Int, val id: Long)

private val Speeds = listOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f, 3f)
private val PanelTint = Color.Black.copy(alpha = 0.55f)
private val ButtonTint = Color.Black.copy(alpha = 0.30f)

@Composable
fun PlayerScreen(player: Player, host: PlayerHost, inPip: Boolean) {
    // The player is always left-to-right (like every video app): the timeline never flips.
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        PlayerContent(player, host, inPip)
    }
}

@OptIn(UnstableApi::class)
@Composable
private fun PlayerContent(player: Player, host: PlayerHost, inPip: Boolean) {
    val s = rememberPlayerState(player)

    var controls by remember { mutableStateOf(true) }
    var panel by remember { mutableStateOf(Panel.NONE) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var audioOnly by remember { mutableStateOf(false) }
    var indicator by remember { mutableStateOf<Indicator?>(null) }
    var indicatorId by remember { mutableIntStateOf(0) }
    var scrub by remember { mutableStateOf<Float?>(null) }
    var seekPreview by remember { mutableStateOf<Long?>(null) }
    var seekFrom by remember { mutableLongStateOf(0L) }
    var flash by remember { mutableStateOf<Flash?>(null) }

    // Controls fade away after a few seconds of playback.
    LaunchedEffect(controls, s.playWhenReady, panel, scrub) {
        if (controls && s.playWhenReady && panel == Panel.NONE && scrub == null) {
            kotlinx.coroutines.delay(3500)
            controls = false
        }
    }
    LaunchedEffect(indicatorId) {
        if (indicator != null) {
            kotlinx.coroutines.delay(900)
            indicator = null
        }
    }
    LaunchedEffect(flash?.id) {
        if (flash != null) {
            kotlinx.coroutines.delay(700)
            flash = null
        }
    }

    // Audio-only mode, and no wasted video decoding while the app is in the background.
    LaunchedEffect(audioOnly) { setVideoDisabled(player, audioOnly) }
    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { setVideoDisabled(player, true) }
    LifecycleEventEffect(Lifecycle.Event.ON_START) { setVideoDisabled(player, audioOnly) }

    BackHandler {
        if (panel != Panel.NONE) panel = Panel.NONE else host.close(audioOnly)
    }

    fun show(item: Indicator) {
        indicator = item
        indicatorId++
    }

    val handler = remember(player) {
        object : GestureHandler {
            var level = 0f
            var leftSide = false

            override fun onTap() {
                controls = !controls
                panel = Panel.NONE
            }

            override fun onDoubleTap(right: Boolean) {
                val duration = s.duration
                val target = player.currentPosition + if (right) 10_000L else -10_000L
                player.seekTo(target.coerceIn(0L, if (duration > 0) duration else Long.MAX_VALUE))
                val previous = flash
                val seconds = if (previous != null && previous.right == right) previous.seconds + 10 else 10
                flash = Flash(right, seconds, System.nanoTime())
            }

            override fun onHorizontalStart() {
                seekFrom = player.currentPosition
                seekPreview = seekFrom
            }

            override fun onHorizontalDrag(totalDx: Float, width: Float) {
                val duration = s.duration
                if (duration <= 0) return
                val span = (duration * 0.5).coerceIn(30_000.0, 240_000.0)
                seekPreview = (seekFrom + totalDx / width * span).toLong().coerceIn(0L, duration)
            }

            override fun onHorizontalEnd() {
                seekPreview?.let { player.seekTo(it) }
                seekPreview = null
            }

            override fun onVerticalStart(left: Boolean) {
                leftSide = left
                level = if (left) host.brightness() else host.volume()
            }

            override fun onVerticalDrag(dy: Float, height: Float) {
                level = (level - dy / height * 1.3f).coerceIn(0f, 1f)
                if (leftSide) {
                    host.setBrightness(level)
                    show(Indicator(Icons.Rounded.BrightnessMedium, "${(level * 100).roundToInt()}%", level))
                } else {
                    host.setVolume(level)
                    val icon = if (level <= 0.001f) Icons.Rounded.VolumeOff else Icons.Rounded.VolumeUp
                    show(Indicator(icon, "${(level * 100).roundToInt()}%", level))
                }
            }

            override fun onVerticalEnd() = Unit

            override fun onZoom(factor: Float) {
                zoom = (zoom * factor).coerceIn(1f, 4f)
                show(Indicator(Icons.Rounded.ZoomIn, "%.1fx".format(zoom), null))
            }

            override fun onZoomEnd() {
                if (zoom < 1.05f) zoom = 1f
            }
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (audioOnly) {
            AudioOnlyBackdrop(s)
        } else {
            AndroidView(
                factory = { ctx -> LayoutInflater.from(ctx).inflate(R.layout.player_view, null) as PlayerView },
                update = { view -> if (view.player !== player) view.player = player },
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        scaleX = zoom
                        scaleY = zoom
                    },
            )
        }

        if (!inPip) {
            GestureLayer(handler, Modifier.fillMaxSize())

            if (s.playbackState == Player.STATE_BUFFERING && !controls) {
                CircularProgressIndicator(
                    color = Color.White,
                    strokeWidth = 3.dp,
                    modifier = Modifier.align(Alignment.Center).size(36.dp),
                )
            }

            AnimatedVisibility(controls, enter = fadeIn(), exit = fadeOut()) {
                Controls(
                    s = s,
                    player = player,
                    host = host,
                    audioOnly = audioOnly,
                    previewPosition = seekPreview,
                    scrub = scrub,
                    onScrub = { scrub = it },
                    onToggleAudioOnly = { audioOnly = !audioOnly },
                    onPanel = { panel = it },
                )
            }

            Overlays(
                indicator = indicator,
                seekPreview = seekPreview,
                seekFrom = seekFrom,
                duration = s.duration,
                flash = flash,
            )

            AnimatedVisibility(panel != Panel.NONE, enter = fadeIn(), exit = fadeOut()) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.35f))
                        .clickable(
                            interactionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() },
                            indication = null,
                        ) { panel = Panel.NONE },
                    contentAlignment = Alignment.Center,
                ) {
                    GlassSurface(
                        modifier = Modifier.widthIn(max = 340.dp).fillMaxWidth(0.82f).heightIn(max = 380.dp),
                        shape = RoundedCornerShape(28.dp),
                        tint = PanelTint,
                        onClick = {},
                        contentAlignment = Alignment.TopStart,
                    ) {
                        when (panel) {
                            Panel.SPEED -> SpeedPanel(s, player) { panel = Panel.NONE }
                            Panel.TRACKS -> TracksPanel(s, player, host) { panel = Panel.NONE }
                            Panel.NONE -> Unit
                        }
                    }
                }
            }
        }
    }
}

private fun setVideoDisabled(player: Player, disabled: Boolean) {
    player.trackSelectionParameters = player.trackSelectionParameters
        .buildUpon()
        .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, disabled)
        .build()
}

@Composable
private fun AudioOnlyBackdrop(s: PlayerState) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        s.uri?.let { Thumb(it, Modifier.fillMaxSize().blur(48.dp).alpha(0.55f)) }
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
            s.uri?.let { Thumb(it, Modifier.size(220.dp).clip(RoundedCornerShape(32.dp))) }
            Spacer(Modifier.height(20.dp))
            Text(
                s.title,
                color = Color.White,
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            Text(stringResource(R.string.player_audio_only), color = Color.White.copy(alpha = 0.7f), fontSize = 14.sp)
        }
    }
}

@Composable
private fun Controls(
    s: PlayerState,
    player: Player,
    host: PlayerHost,
    audioOnly: Boolean,
    previewPosition: Long?,
    scrub: Float?,
    onScrub: (Float?) -> Unit,
    onToggleAudioOnly: () -> Unit,
    onPanel: (Panel) -> Unit,
) {
    val ctx = LocalContext.current
    val pipSupported = remember { ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_PICTURE_IN_PICTURE) }
    val duration = s.duration
    val shownPosition = previewPosition ?: scrub?.let { (it * duration).toLong() } ?: s.position
    val progress = if (duration > 0) shownPosition.toFloat() / duration else 0f
    val bufferedFraction = if (duration > 0) s.buffered.toFloat() / duration else 0f

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color.Black.copy(alpha = 0.55f), Color.Transparent, Color.Transparent, Color.Black.copy(alpha = 0.65f)),
                ),
            ),
    ) {
        // Top: back, title, subtitles/audio, speed
        Row(
            Modifier
                .align(Alignment.TopCenter)
                .safeDrawingPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            GlassIconButton(
                Icons.AutoMirrored.Rounded.ArrowBack, stringResource(R.string.back),
                onClick = { host.close(audioOnly) }, tint = ButtonTint, iconColor = Color.White,
            )
            Text(
                s.title,
                color = Color.White,
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            GlassIconButton(
                Icons.Rounded.ClosedCaption, stringResource(R.string.player_tracks),
                onClick = { onPanel(Panel.TRACKS) }, tint = ButtonTint, iconColor = Color.White,
            )
            GlassSurface(
                shape = CircleShape,
                tint = ButtonTint,
                onClick = { onPanel(Panel.SPEED) },
                modifier = Modifier.height(44.dp),
            ) {
                Text(
                    speedLabel(s.speed),
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 14.dp),
                )
            }
        }

        // Center: round glass transport buttons
        Row(
            Modifier.align(Alignment.Center),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            GlassIconButton(
                Icons.Rounded.SkipPrevious, stringResource(R.string.player_prev),
                onClick = { player.seekToPreviousMediaItem() },
                modifier = Modifier.alpha(if (s.hasPrevious) 1f else 0.4f),
                size = 46.dp, tint = ButtonTint, iconColor = Color.White,
            )
            GlassIconButton(
                Icons.Rounded.Replay10, stringResource(R.string.player_back10),
                onClick = { player.seekTo((player.currentPosition - 10_000).coerceAtLeast(0L)) },
                size = 46.dp, tint = ButtonTint, iconColor = Color.White,
            )
            val ended = s.playbackState == Player.STATE_ENDED
            val showPause = s.playWhenReady && !ended
            GlassIconButton(
                if (showPause) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                stringResource(if (showPause) R.string.player_pause else R.string.player_play),
                onClick = {
                    if (ended) {
                        player.seekTo(0L)
                        player.play()
                    } else if (player.playWhenReady) {
                        player.pause()
                    } else {
                        player.play()
                    }
                },
                size = 72.dp, tint = ButtonTint, iconColor = Color.White,
            )
            GlassIconButton(
                Icons.Rounded.Forward10, stringResource(R.string.player_fwd10),
                onClick = {
                    val limit = if (duration > 0) duration else Long.MAX_VALUE
                    player.seekTo((player.currentPosition + 10_000).coerceAtMost(limit))
                },
                size = 46.dp, tint = ButtonTint, iconColor = Color.White,
            )
            GlassIconButton(
                Icons.Rounded.SkipNext, stringResource(R.string.player_next),
                onClick = { player.seekToNextMediaItem() },
                modifier = Modifier.alpha(if (s.hasNext) 1f else 0.4f),
                size = 46.dp, tint = ButtonTint, iconColor = Color.White,
            )
        }

        // Bottom: times, small actions, thin scrubber
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .safeDrawingPadding()
                .padding(horizontal = 24.dp, vertical = 10.dp),
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(formatDuration(shownPosition), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.weight(1f))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    GlassIconButton(
                        Icons.Rounded.Headphones, stringResource(R.string.player_audio_only),
                        onClick = onToggleAudioOnly, size = 40.dp,
                        tint = if (audioOnly) Color.White.copy(alpha = 0.30f) else ButtonTint, iconColor = Color.White,
                    )
                    if (pipSupported) {
                        GlassIconButton(
                            Icons.Rounded.PictureInPictureAlt, stringResource(R.string.player_pip),
                            onClick = { host.enterPip() }, size = 40.dp, tint = ButtonTint, iconColor = Color.White,
                        )
                    }
                    GlassIconButton(
                        Icons.Rounded.ScreenRotation, stringResource(R.string.player_rotate),
                        onClick = { host.toggleOrientation() }, size = 40.dp, tint = ButtonTint, iconColor = Color.White,
                    )
                }
                Spacer(Modifier.weight(1f))
                Text(formatDuration(duration), color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
            ThinSeekBar(
                progress = progress,
                buffered = bufferedFraction,
                onScrub = { onScrub(it) },
                onCommit = { fraction ->
                    onScrub(null)
                    if (duration > 0) player.seekTo((fraction * duration).toLong())
                },
                onCancel = { onScrub(null) },
            )
        }
    }
}

@Composable
private fun BoxScope.Overlays(
    indicator: Indicator?,
    seekPreview: Long?,
    seekFrom: Long,
    duration: Long,
    flash: Flash?,
) {
    indicator?.let { item ->
        GlassSurface(
            modifier = Modifier.align(Alignment.TopCenter).safeDrawingPadding().padding(top = 72.dp),
            shape = RoundedCornerShape(24.dp),
            tint = PanelTint,
        ) {
            Row(
                Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Icon(item.icon, null, tint = Color.White, modifier = Modifier.size(20.dp))
                if (item.progress != null) {
                    Box(Modifier.size(width = 90.dp, height = 4.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.25f))) {
                        Box(Modifier.fillMaxHeight().fillMaxWidth(item.progress.coerceIn(0f, 1f)).background(Color.White))
                    }
                }
                Text(item.label, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }

    seekPreview?.let { position ->
        val delta = position - seekFrom
        val sign = if (delta >= 0) "+" else "-"
        GlassSurface(
            modifier = Modifier.align(Alignment.Center),
            shape = RoundedCornerShape(28.dp),
            tint = PanelTint,
        ) {
            Column(Modifier.padding(horizontal = 24.dp, vertical = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    "${formatDuration(position)} / ${formatDuration(duration)}",
                    color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold,
                )
                Text(
                    "$sign${formatDuration(abs(delta))}",
                    color = Color.White.copy(alpha = 0.75f), fontSize = 15.sp,
                )
            }
        }
    }

    flash?.let { f ->
        GlassSurface(
            modifier = Modifier
                .align(if (f.right) Alignment.CenterEnd else Alignment.CenterStart)
                .padding(horizontal = 40.dp),
            shape = RoundedCornerShape(28.dp),
            tint = PanelTint,
        ) {
            Row(
                Modifier.padding(horizontal = 18.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Icon(
                    if (f.right) Icons.Rounded.Forward10 else Icons.Rounded.Replay10,
                    null, tint = Color.White, modifier = Modifier.size(24.dp),
                )
                Text("${f.seconds}s", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

private fun speedLabel(speed: Float): String =
    if (speed % 1f == 0f) "${speed.toInt()}x" else "${speed}x".replace(".0x", "x")

@Composable
private fun PanelRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            label,
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        if (selected) Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(20.dp))
    }
}

@Composable
private fun PanelTitle(text: String) {
    Text(
        text,
        color = Color.White.copy(alpha = 0.65f),
        fontSize = 13.sp,
        fontWeight = FontWeight.Medium,
        modifier = Modifier.padding(start = 14.dp, top = 12.dp, bottom = 4.dp),
    )
}

@Composable
private fun SpeedPanel(s: PlayerState, player: Player, onDone: () -> Unit) {
    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(8.dp)) {
        PanelTitle(stringResource(R.string.player_speed))
        Speeds.forEach { speed ->
            PanelRow(speedLabel(speed), abs(s.speed - speed) < 0.01f) {
                player.setPlaybackSpeed(speed)
                onDone()
            }
        }
    }
}

@Composable
private fun TracksPanel(s: PlayerState, player: Player, host: PlayerHost, onDone: () -> Unit) {
    val audio = s.tracks.groups.filter { it.type == C.TRACK_TYPE_AUDIO }
    val text = s.tracks.groups.filter { it.type == C.TRACK_TYPE_TEXT }
    val textDisabled = C.TRACK_TYPE_TEXT in s.params.disabledTrackTypes
    val trackName = stringResource(R.string.player_track)

    Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(8.dp)) {
        if (audio.size > 1) {
            PanelTitle(stringResource(R.string.player_audio))
            audio.forEachIndexed { index, group ->
                PanelRow(trackLabel(group, index, trackName), group.isSelected) {
                    player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                        .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, 0))
                        .build()
                    onDone()
                }
            }
        }
        PanelTitle(stringResource(R.string.player_subtitles))
        PanelRow(stringResource(R.string.player_off), textDisabled || text.none { it.isSelected }) {
            player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                .build()
            onDone()
        }
        text.forEachIndexed { index, group ->
            PanelRow(trackLabel(group, index, trackName), group.isSelected && !textDisabled) {
                player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                    .setOverrideForType(TrackSelectionOverride(group.mediaTrackGroup, 0))
                    .build()
                onDone()
            }
        }
        PanelRow(stringResource(R.string.player_add_sub), false) {
            onDone()
            host.pickSubtitle()
        }
    }
}

private fun trackLabel(group: Tracks.Group, index: Int, fallback: String): String {
    val format = group.getTrackFormat(0)
    val language = format.language
        ?.takeIf { it != "und" }
        ?.let { Locale(it).displayLanguage.replaceFirstChar { c -> c.titlecase() } }
    return listOfNotNull(format.label, language).distinct().joinToString(" · ")
        .ifBlank { "$fallback ${index + 1}" }
}
