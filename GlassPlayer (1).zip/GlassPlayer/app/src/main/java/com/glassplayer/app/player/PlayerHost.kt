package com.glassplayer.app.player

/** What the player screen needs from its Activity (window, audio and system features). */
interface PlayerHost {
    fun close(keepPlaying: Boolean)
    fun enterPip()
    fun toggleOrientation()
    fun brightness(): Float
    fun setBrightness(value: Float)
    fun volume(): Float
    fun setVolume(value: Float)
    fun pickSubtitle()
}
