package com.glassplayer.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

@Immutable
class GlassColors(
    val isDark: Boolean,
    val bg: Color,
    val tint: Color,
    val highlight: Color,
    val sheen: Color,
    val text: Color,
    val textSecondary: Color,
    val accent: Color,
)

val LightGlass = GlassColors(
    isDark = false,
    bg = Color(0xFFF2F2F7),
    tint = Color.White.copy(alpha = 0.50f),
    highlight = Color.White.copy(alpha = 0.90f),
    sheen = Color.White.copy(alpha = 0.35f),
    text = Color(0xFF111114),
    textSecondary = Color(0xFF6B6B73),
    accent = Color(0xFF0A7AFF),
)

val DarkGlass = GlassColors(
    isDark = true,
    bg = Color(0xFF050507),
    tint = Color(0xFF2A2A30).copy(alpha = 0.55f),
    highlight = Color.White.copy(alpha = 0.28f),
    sheen = Color.White.copy(alpha = 0.10f),
    text = Color(0xFFF5F5F7),
    textSecondary = Color(0xFF9A9AA3),
    accent = Color(0xFF4DA3FF),
)

val LocalGlass = staticCompositionLocalOf { LightGlass }

@Composable
fun GlassTheme(forceDark: Boolean = false, content: @Composable () -> Unit) {
    val dark = forceDark || isSystemInDarkTheme()
    val g = if (dark) DarkGlass else LightGlass
    val scheme = if (dark) {
        darkColorScheme(primary = g.accent, background = g.bg, surface = Color(0xFF1C1C22), onSurface = g.text)
    } else {
        lightColorScheme(primary = g.accent, background = g.bg, surface = Color.White, onSurface = g.text)
    }
    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(LocalGlass provides g, LocalContentColor provides g.text) {
            content()
        }
    }
}
