package com.glassplayer.app.player

import android.net.Uri
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionParameters
import androidx.media3.common.Tracks
import kotlinx.coroutines.delay

/** Compose-friendly snapshot of everything the player UI needs to draw. */
@Stable
class PlayerState(private val p: Player) {
    var isPlaying by mutableStateOf(false)
    var playWhenReady by mutableStateOf(false)
    var playbackState by mutableIntStateOf(Player.STATE_IDLE)
    var position by mutableLongStateOf(0L)
    var duration by mutableLongStateOf(0L)
    var buffered by mutableLongStateOf(0L)
    var title by mutableStateOf("")
    var uri by mutableStateOf<Uri?>(null)
    var speed by mutableFloatStateOf(1f)
    var hasNext by mutableStateOf(false)
    var hasPrevious by mutableStateOf(false)
    var tracks by mutableStateOf(Tracks.EMPTY)
    var params by mutableStateOf<TrackSelectionParameters>(TrackSelectionParameters.DEFAULT_WITHOUT_CONTEXT)

    init { sync() }

    fun sync() {
        isPlaying = p.isPlaying
        playWhenReady = p.playWhenReady
        playbackState = p.playbackState
        title = (p.currentMediaItem?.mediaMetadata?.title ?: p.mediaMetadata.title)?.toString().orEmpty()
        uri = p.currentMediaItem?.localConfiguration?.uri
        speed = p.playbackParameters.speed
        hasNext = p.hasNextMediaItem()
        hasPrevious = p.hasPreviousMediaItem()
        tracks = p.currentTracks
        params = p.trackSelectionParameters
        syncPosition()
    }

    fun syncPosition() {
        position = p.currentPosition.coerceAtLeast(0L)
        duration = p.duration.takeIf { it != C.TIME_UNSET }?.coerceAtLeast(0L) ?: 0L
        buffered = p.bufferedPosition.coerceAtLeast(0L)
    }
}

@Composable
fun rememberPlayerState(player: Player): PlayerState {
    val state = remember(player) { PlayerState(player) }
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onEvents(player: Player, events: Player.Events) = state.sync()
        }
        player.addListener(listener)
        state.sync()
        onDispose { player.removeListener(listener) }
    }
    LaunchedEffect(player) {
        while (true) {
            state.syncPosition()
            delay(250)
        }
    }
    return state
}
