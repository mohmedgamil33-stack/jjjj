package com.glassplayer.app.player

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp

/** A thin, Apple-style scrubber: slim track, grows while you drag, thumb only while dragging. */
@Composable
fun ThinSeekBar(
    progress: Float,
    buffered: Float,
    onScrub: (Float) -> Unit,
    onCommit: (Float) -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier,
) {
    var dragging by remember { mutableStateOf(false) }
    val trackHeight by animateDpAsState(if (dragging) 8.dp else 4.dp, label = "seekHeight")
    val scrub = rememberUpdatedState(onScrub)
    val commit = rememberUpdatedState(onCommit)
    val cancel = rememberUpdatedState(onCancel)

    BoxWithConstraints(
        modifier
            .fillMaxWidth()
            .height(32.dp)
            .pointerInput(Unit) {
                detectTapGestures { offset ->
                    commit.value((offset.x / size.width).coerceIn(0f, 1f))
                }
            }
            .pointerInput(Unit) {
                var fraction = 0f
                detectHorizontalDragGestures(
                    onDragStart = { offset ->
                        dragging = true
                        fraction = (offset.x / size.width).coerceIn(0f, 1f)
                        scrub.value(fraction)
                    },
                    onDragEnd = {
                        dragging = false
                        commit.value(fraction)
                    },
                    onDragCancel = {
                        dragging = false
                        cancel.value()
                    },
                    onHorizontalDrag = { change, _ ->
                        fraction = (change.position.x / size.width).coerceIn(0f, 1f)
                        scrub.value(fraction)
                        change.consume()
                    },
                )
            },
        contentAlignment = Alignment.CenterStart,
    ) {
        val p = progress.coerceIn(0f, 1f)
        Box(
            Modifier
                .fillMaxWidth()
                .height(trackHeight)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.25f)),
        ) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(buffered.coerceIn(0f, 1f))
                    .background(Color.White.copy(alpha = 0.35f)),
            )
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(p)
                    .background(Color.White),
            )
        }
        if (dragging) {
            Box(
                Modifier
                    .offset(x = maxWidth * p - 8.dp)
                    .size(16.dp)
                    .background(Color.White, CircleShape),
            )
        }
    }
}
