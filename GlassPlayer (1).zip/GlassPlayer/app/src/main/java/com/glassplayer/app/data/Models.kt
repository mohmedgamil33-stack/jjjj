package com.glassplayer.app.data

import android.net.Uri
import androidx.annotation.StringRes
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import com.glassplayer.app.R

data class VideoItem(
    val id: Long,
    val uri: Uri,
    val title: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val dateAddedSec: Long,
    val folderId: Long,
    val folderName: String,
)

data class FolderItem(val id: Long, val name: String, val videos: List<VideoItem>)

enum class LayoutMode { GRID, LIST }

enum class SortOrder(@StringRes val label: Int) {
    DATE(R.string.sort_date),
    NAME(R.string.sort_name),
    DURATION(R.string.sort_duration),
    SIZE(R.string.sort_size),
}

data class AppSettings(
    val backgroundPlayback: Boolean = true,
    val autoPip: Boolean = true,
    val matchOrientation: Boolean = true,
    val resume: Boolean = true,
    val dynamicColors: Boolean = true,
)

fun List<VideoItem>.applySort(order: SortOrder): List<VideoItem> = when (order) {
    SortOrder.DATE -> sortedByDescending { it.dateAddedSec }
    SortOrder.NAME -> sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.title })
    SortOrder.DURATION -> sortedByDescending { it.durationMs }
    SortOrder.SIZE -> sortedByDescending { it.sizeBytes }
}

fun List<VideoItem>.toFolders(order: SortOrder): List<FolderItem> {
    val folders = groupBy { it.folderId }.map { (id, list) ->
        FolderItem(id, list.first().folderName, list.applySort(order))
    }
    return if (order == SortOrder.NAME) {
        folders.sortedWith(compareBy(String.CASE_INSENSITIVE_ORDER) { it.name })
    } else {
        folders.sortedByDescending { f -> f.videos.maxOf { it.dateAddedSec } }
    }
}

fun VideoItem.toMediaItem(): MediaItem =
    MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(MediaMetadata.Builder().setTitle(title).build())
        .build()
