package com.glassplayer.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.glassplayer.app.data.VideoItem
import com.glassplayer.app.data.toMediaItem
import com.glassplayer.app.player.PlayerActivity
import com.glassplayer.app.player.PlayerQueue
import com.glassplayer.app.ui.MainViewModel
import com.glassplayer.app.ui.glass.AmbientBackground
import com.glassplayer.app.ui.glass.GlassSurface
import com.glassplayer.app.ui.home.HomeScreen
import com.glassplayer.app.ui.theme.GlassTheme
import com.glassplayer.app.ui.theme.LocalGlass

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GlassTheme { Root(vm, ::play) }
        }
    }

    private fun play(videos: List<VideoItem>, index: Int) {
        PlayerQueue.set(videos.map { it.toMediaItem() }, index)
        startActivity(Intent(this, PlayerActivity::class.java))
    }
}

@Composable
private fun Root(vm: MainViewModel, onPlay: (List<VideoItem>, Int) -> Unit) {
    val ctx = LocalContext.current
    val permission = if (Build.VERSION.SDK_INT >= 33) {
        Manifest.permission.READ_MEDIA_VIDEO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }
    fun isGranted() = ContextCompat.checkSelfPermission(ctx, permission) == PackageManager.PERMISSION_GRANTED

    var granted by remember { mutableStateOf(isGranted()) }
    var requested by remember { mutableStateOf(false) }

    val notifications = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        granted = ok
        val activity = ctx as? Activity
        if (!ok && requested && activity != null &&
            !ActivityCompat.shouldShowRequestPermissionRationale(activity, permission)
        ) {
            // Permanently denied: send the person to the app settings page.
            ctx.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", ctx.packageName, null)),
            )
        }
    }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        granted = isGranted()
        if (granted) vm.refresh()
    }
    LaunchedEffect(granted) {
        if (granted && Build.VERSION.SDK_INT >= 33) {
            notifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    if (granted) {
        HomeScreen(vm, onPlay)
    } else {
        PermissionScreen {
            requested = true
            launcher.launch(permission)
        }
    }
}

@Composable
private fun PermissionScreen(onRequest: () -> Unit) {
    val g = LocalGlass.current
    Box(Modifier.fillMaxSize()) {
        AmbientBackground(null)
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            GlassSurface(Modifier.size(120.dp), CircleShape) {
                Icon(Icons.Rounded.PlayArrow, null, tint = g.accent, modifier = Modifier.size(60.dp))
            }
            Spacer(Modifier.height(28.dp))
            Text(
                stringResource(R.string.perm_title),
                color = g.text,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(10.dp))
            Text(
                stringResource(R.string.perm_body),
                color = g.textSecondary,
                fontSize = 15.sp,
                textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(32.dp))
            GlassSurface(
                shape = RoundedCornerShape(28.dp),
                tint = g.accent,
                onClick = onRequest,
            ) {
                Text(
                    stringResource(R.string.perm_button),
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 36.dp, vertical = 16.dp),
                )
            }
        }
    }
}
