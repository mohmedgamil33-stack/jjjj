package com.glassplayer.app.player

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.pointer.positionChanged
import kotlin.math.abs
import kotlin.math.hypot

interface GestureHandler {
    fun onTap()
    fun onDoubleTap(right: Boolean)
    fun onHorizontalStart()
    fun onHorizontalDrag(totalDx: Float, width: Float)
    fun onHorizontalEnd()
    fun onVerticalStart(left: Boolean)
    fun onVerticalDrag(dy: Float, height: Float)
    fun onVerticalEnd()
    fun onZoom(factor: Float)
    fun onZoomEnd()
}

/**
 * One layer that understands every player gesture:
 *  - tap: show or hide the controls
 *  - double tap on either side: jump 10 seconds
 *  - horizontal drag: scrub through the video
 *  - vertical drag on the left half: brightness, on the right half: volume
 *  - two-finger pinch: zoom
 */
@Composable
fun GestureLayer(handler: GestureHandler, modifier: Modifier = Modifier) {
    val current = rememberUpdatedState(handler)
    Box(
        modifier
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = { current.value.onTap() },
                    onDoubleTap = { offset -> current.value.onDoubleTap(offset.x > size.width / 2f) },
                )
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    val down = awaitFirstDown(requireUnconsumed = false)
                    val slop = viewConfiguration.touchSlop * 2f
                    val startedLeft = down.position.x < size.width / 2f
                    var mode = Mode.NONE
                    var totalX = 0f
                    var totalY = 0f
                    do {
                        val event = awaitPointerEvent()
                        val pressed = event.changes.count { it.pressed }
                        if (pressed >= 2) {
                            when (mode) {
                                Mode.HORIZONTAL -> current.value.onHorizontalEnd()
                                Mode.VERTICAL -> current.value.onVerticalEnd()
                                else -> Unit
                            }
                            mode = Mode.PINCH
                            val zoom = event.calculateZoom()
                            if (zoom != 1f) {
                                current.value.onZoom(zoom)
                                event.changes.forEach { if (it.positionChanged()) it.consume() }
                            }
                        } else if (mode != Mode.PINCH) {
                            val change = event.changes.firstOrNull() ?: break
                            val delta = change.positionChange()
                            totalX += delta.x
                            totalY += delta.y
                            if (mode == Mode.NONE && hypot(totalX, totalY) > slop) {
                                mode = if (abs(totalX) > abs(totalY)) Mode.HORIZONTAL else Mode.VERTICAL
                                if (mode == Mode.HORIZONTAL) current.value.onHorizontalStart()
                                else current.value.onVerticalStart(startedLeft)
                            }
                            if (mode == Mode.HORIZONTAL) {
                                current.value.onHorizontalDrag(totalX, size.width.toFloat())
                                change.consume()
                            } else if (mode == Mode.VERTICAL) {
                                current.value.onVerticalDrag(delta.y, size.height.toFloat())
                                change.consume()
                            }
                        }
                    } while (event.changes.any { it.pressed })

                    when (mode) {
                        Mode.HORIZONTAL -> current.value.onHorizontalEnd()
                        Mode.VERTICAL -> current.value.onVerticalEnd()
                        Mode.PINCH -> current.value.onZoomEnd()
                        Mode.NONE -> Unit
                    }
                }
            },
    )
}

private enum class Mode { NONE, HORIZONTAL, VERTICAL, PINCH }
