package com.glassplayer.app.ui.home

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.GridView
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SwapVert
import androidx.compose.material.icons.rounded.VideoLibrary
import androidx.compose.material.icons.rounded.ViewAgenda
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.annotation.StringRes
import com.glassplayer.app.R
import com.glassplayer.app.data.FolderItem
import com.glassplayer.app.data.LayoutMode
import com.glassplayer.app.data.SortOrder
import com.glassplayer.app.data.VideoItem
import com.glassplayer.app.data.applySort
import com.glassplayer.app.data.toFolders
import com.glassplayer.app.ui.MainViewModel
import com.glassplayer.app.ui.glass.AmbientBackground
import com.glassplayer.app.ui.glass.GlassIconButton
import com.glassplayer.app.ui.glass.GlassState
import com.glassplayer.app.ui.glass.GlassSurface
import com.glassplayer.app.ui.glass.glassSource
import com.glassplayer.app.ui.glass.rememberGlassState
import com.glassplayer.app.ui.theme.LocalGlass
import com.glassplayer.app.ui.theme.asAccent
import com.glassplayer.app.ui.theme.rememberDominantColor

private data class TabSpec(val icon: ImageVector, @StringRes val label: Int)

private val Tabs = listOf(
    TabSpec(Icons.Rounded.Folder, R.string.tab_folders),
    TabSpec(Icons.Rounded.VideoLibrary, R.string.tab_videos),
    TabSpec(Icons.Rounded.Favorite, R.string.tab_favorites),
    TabSpec(Icons.Rounded.Settings, R.string.tab_settings),
)

@Composable
fun HomeScreen(vm: MainViewModel, onPlay: (List<VideoItem>, Int) -> Unit) {
    val g = LocalGlass.current
    val glass = rememberGlassState()
    var barVisible by remember { mutableStateOf(true) }
    var ambientUri by remember { mutableStateOf<Uri?>(null) }

    // Scroll down hides the floating tab bar, scroll up brings it back.
    val connection = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (available.y < -6f) barVisible = false
                else if (available.y > 6f) barVisible = true
                return Offset.Zero
            }
        }
    }
    LaunchedEffect(vm.tab, vm.openFolderId) { barVisible = true }
    BackHandler(enabled = vm.tab == 0 && vm.openFolderId != null) { vm.openFolderId = null }

    val folders = remember(vm.videos, vm.sort) { vm.videos.toFolders(vm.sort) }
    val allVideos = remember(vm.videos, vm.sort) { vm.videos.applySort(vm.sort) }
    val favVideos = remember(allVideos, vm.favorites) { allVideos.filter { it.id in vm.favorites } }

    val dynamic = vm.settings.dynamicColors && vm.tab != 3
    val ambientColor = if (dynamic) rememberDominantColor(ambientUri) else null
    val accent = ambientColor?.asAccent(g.isDark) ?: g.accent

    val holder = rememberSaveableStateHolder()

    Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().glassSource(glass).nestedScroll(connection)) {
            AmbientBackground(ambientColor)
            holder.SaveableStateProvider("${vm.tab}:${vm.openFolderId}") {
                when (vm.tab) {
                    0 -> {
                        val open = vm.openFolderId?.let { id -> folders.find { it.id == id } }
                        if (open != null) {
                            VideoCollection(
                                title = open.name,
                                subtitle = stringResource(R.string.n_videos, open.videos.size),
                                videos = open.videos,
                                vm = vm,
                                glass = glass,
                                emptyTitle = stringResource(R.string.empty_title),
                                emptyBody = stringResource(R.string.empty_body),
                                onBack = { vm.openFolderId = null },
                                onPlay = { i -> onPlay(open.videos, i) },
                                onAmbient = { ambientUri = it },
                            )
                        } else {
                            FolderCollection(
                                folders = folders,
                                vm = vm,
                                glass = glass,
                                onOpen = { vm.openFolderId = it.id },
                                onAmbient = { ambientUri = it },
                            )
                        }
                    }
                    1 -> VideoCollection(
                        title = stringResource(R.string.tab_videos),
                        subtitle = stringResource(R.string.n_videos, allVideos.size),
                        videos = allVideos,
                        vm = vm,
                        glass = glass,
                        emptyTitle = stringResource(R.string.empty_title),
                        emptyBody = stringResource(R.string.empty_body),
                        onBack = null,
                        onPlay = { i -> onPlay(allVideos, i) },
                        onAmbient = { ambientUri = it },
                    )
                    2 -> VideoCollection(
                        title = stringResource(R.string.tab_favorites),
                        subtitle = stringResource(R.string.n_videos, favVideos.size),
                        videos = favVideos,
                        vm = vm,
                        glass = glass,
                        emptyTitle = stringResource(R.string.fav_empty_title),
                        emptyBody = stringResource(R.string.fav_empty_body),
                        onBack = null,
                        onPlay = { i -> onPlay(favVideos, i) },
                        onAmbient = { ambientUri = it },
                    )
                    else -> SettingsScreen(vm.settings, vm::updateSettings, accent)
                }
            }
        }

        AnimatedVisibility(
            visible = barVisible,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .navigationBarsPadding()
                .padding(bottom = 12.dp),
        ) {
            GlassTabBar(vm.tab, accent, glass) { vm.tab = it }
        }
    }
}

@Composable
private fun GlassTabBar(selected: Int, accent: Color, glass: GlassState, onSelect: (Int) -> Unit) {
    val g = LocalGlass.current
    GlassSurface(shape = CircleShape, glass = glass, blur = 30.dp) {
        Row(
            Modifier.padding(6.dp).animateContentSize(),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Tabs.forEachIndexed { i, tab ->
                val isSelected = i == selected
                val bg by animateColorAsState(
                    if (isSelected) accent.copy(alpha = 0.20f) else Color.Transparent,
                    label = "tab",
                )
                Row(
                    Modifier
                        .height(48.dp)
                        .clip(CircleShape)
                        .background(bg)
                        .clickable { onSelect(i) }
                        .padding(horizontal = if (isSelected) 16.dp else 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Icon(
                        tab.icon,
                        contentDescription = stringResource(tab.label),
                        tint = if (isSelected) accent else g.textSecondary,
                        modifier = Modifier.size(24.dp),
                    )
                    if (isSelected) {
                        Text(
                            stringResource(tab.label),
                            color = accent,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ScreenHeader(
    title: String,
    subtitle: String?,
    onBack: (() -> Unit)?,
    glass: GlassState,
    actions: @Composable () -> Unit,
) {
    val g = LocalGlass.current
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().padding(top = 8.dp, bottom = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        if (onBack != null) {
            GlassIconButton(
                icon = Icons.AutoMirrored.Rounded.ArrowBack,
                description = stringResource(R.string.back),
                onClick = onBack,
                glass = glass,
            )
        }
        Column(Modifier.weight(1f)) {
            Text(
                title,
                color = g.text,
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
            )
            if (subtitle != null) {
                Text(subtitle, color = g.textSecondary, fontSize = 14.sp)
            }
        }
        actions()
    }
}

@Composable
private fun HeaderActions(vm: MainViewModel, glass: GlassState) {
    var menu by remember { mutableStateOf(false) }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        GlassIconButton(
            icon = if (vm.layoutMode == LayoutMode.GRID) Icons.Rounded.ViewAgenda else Icons.Rounded.GridView,
            description = stringResource(R.string.layout_toggle),
            onClick = { vm.toggleLayout() },
            glass = glass,
        )
        Box {
            GlassIconButton(
                icon = Icons.Rounded.SwapVert,
                description = stringResource(R.string.sort_label),
                onClick = { menu = true },
                glass = glass,
            )
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                SortOrder.entries.forEach { order ->
                    DropdownMenuItem(
                        text = { Text(stringResource(order.label)) },
                        onClick = {
                            vm.setSort(order)
                            menu = false
                        },
                        trailingIcon = {
                            if (vm.sort == order) Icon(Icons.Rounded.Check, contentDescription = null)
                        },
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyState(title: String, body: String) {
    val g = LocalGlass.current
    Column(
        Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 72.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Text(title, color = g.text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        Text(body, color = g.textSecondary, fontSize = 15.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun FolderCollection(
    folders: List<FolderItem>,
    vm: MainViewModel,
    glass: GlassState,
    onOpen: (FolderItem) -> Unit,
    onAmbient: (Uri?) -> Unit,
) {
    val state = rememberLazyGridState()
    val first by remember { derivedStateOf { state.firstVisibleItemIndex } }
    LaunchedEffect(first, folders) {
        onAmbient(folders.getOrNull((first - 1).coerceAtLeast(0))?.videos?.firstOrNull()?.uri)
    }
    val grid = vm.layoutMode == LayoutMode.GRID
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    LazyVerticalGrid(
        state = state,
        columns = if (grid) GridCells.Adaptive(160.dp) else GridCells.Fixed(1),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 120.dp + bottomInset),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            ScreenHeader(
                title = stringResource(R.string.tab_folders),
                subtitle = stringResource(R.string.n_folders, folders.size),
                onBack = null,
                glass = glass,
            ) { HeaderActions(vm, glass) }
        }
        if (folders.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                if (vm.loaded) EmptyState(stringResource(R.string.empty_title), stringResource(R.string.empty_body))
            }
        }
        itemsIndexed(folders, key = { _, f -> f.id }) { _, folder ->
            if (grid) FolderStackCard(folder) { onOpen(folder) } else FolderRow(folder) { onOpen(folder) }
        }
    }
}

@Composable
private fun VideoCollection(
    title: String,
    subtitle: String?,
    videos: List<VideoItem>,
    vm: MainViewModel,
    glass: GlassState,
    emptyTitle: String,
    emptyBody: String,
    onBack: (() -> Unit)?,
    onPlay: (Int) -> Unit,
    onAmbient: (Uri?) -> Unit,
) {
    val state = rememberLazyGridState()
    val first by remember { derivedStateOf { state.firstVisibleItemIndex } }
    LaunchedEffect(first, videos) {
        onAmbient(videos.getOrNull((first - 1).coerceAtLeast(0))?.uri)
    }
    val grid = vm.layoutMode == LayoutMode.GRID
    val bottomInset = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    LazyVerticalGrid(
        state = state,
        columns = if (grid) GridCells.Adaptive(160.dp) else GridCells.Fixed(1),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 120.dp + bottomInset),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            ScreenHeader(title, subtitle, onBack, glass) { HeaderActions(vm, glass) }
        }
        if (videos.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                if (vm.loaded) EmptyState(emptyTitle, emptyBody)
            }
        }
        itemsIndexed(videos, key = { _, v -> v.id }) { index, video ->
            val fav = video.id in vm.favorites
            if (grid) {
                VideoGridCard(video, fav, { onPlay(index) }, { vm.toggleFavorite(video.id) })
            } else {
                VideoRow(video, fav, { onPlay(index) }, { vm.toggleFavorite(video.id) })
            }
        }
    }
}
