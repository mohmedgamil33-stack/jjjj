package com.glassplayer.app.ui.home

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.glassplayer.app.R
import com.glassplayer.app.data.FolderItem
import com.glassplayer.app.data.VideoItem
import com.glassplayer.app.ui.Thumb
import com.glassplayer.app.ui.glass.GlassIconButton
import com.glassplayer.app.ui.glass.GlassSurface
import com.glassplayer.app.ui.theme.LocalGlass
import com.glassplayer.app.util.formatDuration
import com.glassplayer.app.util.formatSize

private val ImagePillTint = Color.Black.copy(alpha = 0.38f)
private val FavColor = Color(0xFFFF5A7A)

@Composable
private fun FavButton(
    fav: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    onImage: Boolean = true,
) {
    val g = LocalGlass.current
    GlassIconButton(
        icon = if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
        description = stringResource(R.string.favorite),
        onClick = onClick,
        modifier = modifier,
        size = 34.dp,
        tint = if (onImage) Color.Black.copy(alpha = 0.30f) else null,
        iconColor = if (fav) FavColor else if (onImage) Color.White else g.text,
    )
}

/** Big rounded thumbnail with a small glass plate (title and duration) floating on it. */
@Composable
fun VideoGridCard(video: VideoItem, fav: Boolean, onClick: () -> Unit, onFav: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .aspectRatio(1.3f)
            .clip(RoundedCornerShape(24.dp))
            .clickable(onClick = onClick),
    ) {
        Thumb(video.uri, Modifier.fillMaxSize())
        FavButton(fav, onFav, Modifier.align(Alignment.TopEnd).padding(8.dp))
        GlassSurface(
            modifier = Modifier.align(Alignment.BottomCenter).padding(8.dp).fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            tint = ImagePillTint,
            contentAlignment = Alignment.CenterStart,
        ) {
            Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                Text(
                    video.title,
                    color = Color.White,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(formatDuration(video.durationMs), color = Color.White.copy(alpha = 0.78f), fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun VideoRow(video: VideoItem, fav: Boolean, onClick: () -> Unit, onFav: () -> Unit) {
    val g = LocalGlass.current
    GlassSurface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        onClick = onClick,
        contentAlignment = Alignment.CenterStart,
    ) {
        Row(
            Modifier.padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Box(Modifier.width(116.dp).height(72.dp).clip(RoundedCornerShape(16.dp))) {
                Thumb(video.uri, Modifier.fillMaxSize())
            }
            Column(Modifier.weight(1f)) {
                Text(
                    video.title,
                    color = g.text,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    "${formatDuration(video.durationMs)}  •  ${formatSize(video.sizeBytes)}",
                    color = g.textSecondary,
                    fontSize = 12.sp,
                )
            }
            FavButton(fav, onFav, onImage = false)
        }
    }
}

/** Folder shown as a small pile of overlapping photos, like an album. */
@Composable
fun FolderStackCard(folder: FolderItem, onClick: () -> Unit) {
    val g = LocalGlass.current
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .clickable(onClick = onClick)
            .padding(bottom = 4.dp),
    ) {
        Box(Modifier.fillMaxWidth().aspectRatio(1.2f), contentAlignment = Alignment.BottomCenter) {
            val covers = folder.videos.take(3)
            for (depth in covers.indices.reversed()) {
                val shape = RoundedCornerShape(18.dp)
                Thumb(
                    covers[depth].uri,
                    Modifier
                        .fillMaxWidth(1f - depth * 0.09f)
                        .aspectRatio(1.35f)
                        .offset(y = (-14 * depth).dp)
                        .graphicsLayer {
                            rotationZ = when (depth) {
                                0 -> 0f
                                1 -> -3.5f
                                else -> 4f
                            }
                        }
                        .clip(shape)
                        .border(1.5.dp, g.highlight, shape),
                )
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(
            folder.name,
            color = g.text,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
        Text(
            stringResource(R.string.n_videos, folder.videos.size),
            color = g.textSecondary,
            fontSize = 13.sp,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
    }
}

@Composable
fun FolderRow(folder: FolderItem, onClick: () -> Unit) {
    val g = LocalGlass.current
    GlassSurface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        onClick = onClick,
        contentAlignment = Alignment.CenterStart,
    ) {
        Row(
            Modifier.padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Box(Modifier.size(72.dp).clip(RoundedCornerShape(16.dp))) {
                Thumb(folder.videos.first().uri, Modifier.fillMaxSize())
            }
            Column(Modifier.weight(1f)) {
                Text(
                    folder.name,
                    color = g.text,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    stringResource(R.string.n_videos, folder.videos.size),
                    color = g.textSecondary,
                    fontSize = 13.sp,
                )
            }
        }
    }
}
