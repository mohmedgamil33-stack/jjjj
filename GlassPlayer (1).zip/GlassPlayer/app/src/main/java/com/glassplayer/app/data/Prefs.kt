package com.glassplayer.app.data

import android.content.Context

class Prefs private constructor(ctx: Context) {
    private val sp = ctx.getSharedPreferences("glass_player", Context.MODE_PRIVATE)

    var layoutMode: LayoutMode
        get() = runCatching { LayoutMode.valueOf(sp.getString("layout", null) ?: "GRID") }
            .getOrDefault(LayoutMode.GRID)
        set(v) { sp.edit().putString("layout", v.name).apply() }

    var sort: SortOrder
        get() = runCatching { SortOrder.valueOf(sp.getString("sort", null) ?: "DATE") }
            .getOrDefault(SortOrder.DATE)
        set(v) { sp.edit().putString("sort", v.name).apply() }

    var settings: AppSettings
        get() = AppSettings(
            backgroundPlayback = sp.getBoolean("s_bg", true),
            autoPip = sp.getBoolean("s_pip", true),
            matchOrientation = sp.getBoolean("s_rotate", true),
            resume = sp.getBoolean("s_resume", true),
            dynamicColors = sp.getBoolean("s_dynamic", true),
        )
        set(v) {
            sp.edit()
                .putBoolean("s_bg", v.backgroundPlayback)
                .putBoolean("s_pip", v.autoPip)
                .putBoolean("s_rotate", v.matchOrientation)
                .putBoolean("s_resume", v.resume)
                .putBoolean("s_dynamic", v.dynamicColors)
                .apply()
        }

    fun favorites(): Set<Long> =
        sp.getStringSet("fav", emptySet()).orEmpty().mapNotNull { it.toLongOrNull() }.toSet()

    fun saveFavorites(ids: Set<Long>) {
        sp.edit().putStringSet("fav", ids.map { it.toString() }.toSet()).apply()
    }

    fun position(id: Long?): Long = if (id == null) 0L else sp.getLong("pos_$id", 0L)

    fun savePosition(id: Long, positionMs: Long) {
        sp.edit().putLong("pos_$id", positionMs).apply()
    }

    companion object {
        @Volatile private var instance: Prefs? = null
        fun get(ctx: Context): Prefs = instance ?: synchronized(this) {
            instance ?: Prefs(ctx.applicationContext).also { instance = it }
        }
    }
}
