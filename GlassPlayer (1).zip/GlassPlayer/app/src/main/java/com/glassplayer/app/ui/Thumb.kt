package com.glassplayer.app.ui

import android.content.Context
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import coil.compose.AsyncImage
import coil.request.ImageRequest
import coil.request.videoFrameMillis
import com.glassplayer.app.ui.theme.LocalGlass

fun thumbRequest(ctx: Context, uri: Uri, sizePx: Int? = null): ImageRequest =
    ImageRequest.Builder(ctx)
        .data(uri)
        .videoFrameMillis(1500)
        .apply {
            if (sizePx != null) {
                size(sizePx)
                allowHardware(false)
            }
        }
        .crossfade(true)
        .build()

@Composable
fun Thumb(uri: Uri, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val request = remember(uri) { thumbRequest(ctx, uri) }
    AsyncImage(
        model = request,
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier = modifier.background(LocalGlass.current.tint),
    )
}
