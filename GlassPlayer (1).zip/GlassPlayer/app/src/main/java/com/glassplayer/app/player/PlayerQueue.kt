package com.glassplayer.app.player

import androidx.media3.common.MediaItem

/** Hands the chosen playlist from the home screen to the player screen. */
object PlayerQueue {
    class Pending(val items: List<MediaItem>, val index: Int)

    @Volatile private var pending: Pending? = null

    fun set(items: List<MediaItem>, index: Int) {
        pending = Pending(items, index)
    }

    fun take(): Pending? = pending.also { pending = null }
}
