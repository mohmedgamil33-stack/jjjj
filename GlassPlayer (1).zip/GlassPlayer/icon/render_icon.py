"""Renders icon_preview.png (and the 512px Play Store icon) with the same geometry as the Android vector icon."""
import numpy as np
from PIL import Image, ImageDraw

S = 2                     # supersampling factor
N = 1024 * S

def hexrgb(h):
    h = h.lstrip('#')
    return np.array([int(h[i:i + 2], 16) for i in (0, 2, 4)], dtype=np.float32)

yy, xx = np.mgrid[0:N, 0:N].astype(np.float32)
xx /= S; yy /= S

def interp(t, stops):
    t = np.clip(t, 0, 1)
    offs = [s[0] for s in stops]
    out = np.zeros(t.shape + (4,), dtype=np.float32)
    for c in range(3):
        out[..., c] = np.interp(t, offs, [hexrgb(s[1])[c] for s in stops])
    out[..., 3] = np.interp(t, offs, [s[2] for s in stops]) * 255
    return out

def linear(p0, p1, stops):
    d = np.array(p1, dtype=np.float32) - np.array(p0, dtype=np.float32)
    t = ((xx - p0[0]) * d[0] + (yy - p0[1]) * d[1]) / float(d @ d)
    return interp(t, stops)

def radial(c, r, stops):
    return interp(np.hypot(xx - c[0], yy - c[1]) / r, stops)

def to_img(arr):
    return Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8), 'RGBA')

def masked(arr, mask):
    arr = arr.copy()
    arr[..., 3] *= np.asarray(mask, dtype=np.float32) / 255.0
    return to_img(arr)

def mask_from(draw_fn):
    m = Image.new('L', (N, N), 0)
    draw_fn(ImageDraw.Draw(m))
    return m

def bezier(p0, p1, p2, p3, n=48):
    t = np.linspace(0, 1, n)[:, None]
    p0, p1, p2, p3 = map(np.array, (p0, p1, p2, p3))
    return ((1 - t) ** 3 * p0 + 3 * (1 - t) ** 2 * t * p1 + 3 * (1 - t) * t ** 2 * p2 + t ** 3 * p3).tolist()

def sc(pts):
    return [(x * S, y * S) for x, y in pts]

canvas = Image.new('RGBA', (N, N), (0, 0, 0, 0))

# rounded-square mask
def rr(d): d.rounded_rectangle([0, 0, N - 1, N - 1], radius=230 * S, fill=255)
mask_sq = mask_from(rr)

bg = linear((0, 0), (1024, 1024), [(0, '#2D1B8E', 1), (.55, '#7B3FF2', 1), (1, '#FF5DA2', 1)])
cyan = radial((190, 854), 570, [(0, '#22D3EE', .75), (1, '#22D3EE', 0)])
amber = radial((806, 171), 427, [(0, '#FFB347', .70), (1, '#FFB347', 0)])
base = to_img(bg)
base = Image.alpha_composite(base, to_img(cyan))
base = Image.alpha_composite(base, to_img(amber))

# ground shadow
shadow = radial((512, 569), 322, [(0, '#000000', .35), (.7, '#000000', .14), (1, '#000000', 0)])
base = Image.alpha_composite(base, to_img(shadow))

# glass disc
disc_mask = mask_from(lambda d: d.ellipse([(512 - 256) * S, (512 - 256) * S, (512 + 256) * S, (512 + 256) * S], fill=255))
disc = linear((341, 256), (683, 768), [(0, '#FFFFFF', .62), (1, '#FFFFFF', .12)])
base = Image.alpha_composite(base, masked(disc, disc_mask))

# bevelled rim
def ring(d):
    d.ellipse([(512 - 256) * S, (512 - 256) * S, (512 + 256) * S, (512 + 256) * S], fill=255)
    d.ellipse([(512 - 244) * S, (512 - 244) * S, (512 + 244) * S, (512 + 244) * S], fill=0)
rim = linear((322, 265), (702, 758), [(0, '#FFFFFF', .95), (.5, '#FFFFFF', .10), (1, '#FFFFFF', .50)])
base = Image.alpha_composite(base, masked(rim, mask_from(ring)))

# top specular highlight
spec_pts = bezier((351, 427), (389, 316), (635, 316), (673, 427)) + bezier((673, 427), (597, 379), (427, 379), (351, 427))
spec = linear((512, 313), (512, 427), [(0, '#FFFFFF', .55), (1, '#FFFFFF', 0)])
base = Image.alpha_composite(base, masked(spec, mask_from(lambda d: d.polygon(sc(spec_pts), fill=255))))

# bottom inner reflection
refl_pts = bezier((379, 645), (455, 730), (626, 730), (683, 626)) + bezier((683, 626), (607, 673), (455, 673), (379, 645))
refl = np.zeros((N, N, 4), dtype=np.float32); refl[..., :3] = 255; refl[..., 3] = 0.18 * 255
base = Image.alpha_composite(base, masked(refl, mask_from(lambda d: d.polygon(sc(refl_pts), fill=255))))

def rounded_triangle_mask(pts, r):
    def draw(d):
        d.polygon(sc(pts), fill=255)
        for i in range(3):
            a, b = pts[i], pts[(i + 1) % 3]
            d.line(sc([a, b]), fill=255, width=int(2 * r * S))
            d.ellipse([(a[0] - r) * S, (a[1] - r) * S, (a[0] + r) * S, (a[1] + r) * S], fill=255)
    return mask_from(draw)

tri = [(436, 384), (436, 640), (650, 512)]
tri_shadow = [(446, 400), (446, 656), (660, 528)]
sh = np.zeros((N, N, 4), dtype=np.float32); sh[..., 3] = 0.32 * 255
base = Image.alpha_composite(base, masked(sh, rounded_triangle_mask(tri_shadow, 16.5)))
fill = linear((0, 379), (0, 645), [(0, '#FFFFFF', 1), (1, '#D9E6FF', 1)])
fill = linear((436, 384), (436, 640), [(0, '#FFFFFF', 1), (1, '#D9E6FF', 1)])
base = Image.alpha_composite(base, masked(fill, rounded_triangle_mask(tri, 16.5)))

# apply rounded-square mask and downsample
alpha = np.asarray(base)[..., 3].astype(np.float32) * np.asarray(mask_sq, dtype=np.float32) / 255.0
out = np.asarray(base).copy(); out[..., 3] = alpha
final = Image.fromarray(out.astype(np.uint8), 'RGBA').resize((1024, 1024), Image.LANCZOS)
final.save('icon_preview.png')
final.resize((512, 512), Image.LANCZOS).save('playstore_icon_512.png')
print('rendered')
